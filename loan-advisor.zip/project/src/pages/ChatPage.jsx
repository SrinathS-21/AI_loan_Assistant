import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { ChevronLeft, Send, Lightbulb } from 'lucide-react';

const suggestions = [
  "What's my current load status?",
  "How can I optimize my training load?",
  "Show me my recovery metrics",
  "Generate a training plan"
];

function ChatPage() {
  const navigate = useNavigate();
  const [input, setInput] = useState('');
  const [messages, setMessages] = useState([
    {
      type: 'assistant',
      content: "Hello! I'm your Load Advisor assistant. How can I help you today?"
    }
  ]);

  const handleSend = () => {
    if (!input.trim()) return;
    
    setMessages([
      ...messages,
      { type: 'user', content: input },
      { type: 'assistant', content: 'This is a mock response. Backend integration coming soon!' }
    ]);
    setInput('');
  };

  const handleKeyPress = (e) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  };

  return (
    <div className="min-h-screen bg-base-200 flex flex-col">
      <div className="bg-base-100 shadow-md">
        <div className="max-w-7xl mx-auto px-4 py-4">
          <button
            onClick={() => navigate('/')}
            className="btn btn-ghost gap-2"
          >
            <ChevronLeft size={20} />
            <span>Back to Home</span>
          </button>
        </div>
      </div>

      <div className="flex-1 max-w-7xl w-full mx-auto px-4 py-8 flex flex-col">
        {/* Messages */}
        <div className="flex-1 space-y-4 mb-8">
          {messages.map((message, index) => (
            <div
              key={index}
              className={`flex ${message.type === 'user' ? 'justify-end' : 'justify-start'}`}
            >
              <div
                className={`max-w-[80%] rounded-lg p-4 ${
                  message.type === 'user'
                    ? 'bg-primary text-white'
                    : 'bg-base-100 shadow-md'
                }`}
              >
                {message.content}
              </div>
            </div>
          ))}
        </div>

        {/* Suggestions */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-8">
          {suggestions.map((suggestion, index) => (
            <button
              key={index}
              className="btn btn-outline gap-2"
              onClick={() => setInput(suggestion)}
            >
              <Lightbulb size={16} />
              {suggestion}
            </button>
          ))}
        </div>

        {/* Input */}
        <div className="bg-base-100 rounded-lg shadow-lg p-4">
          <div className="flex gap-4">
            <textarea
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyPress={handleKeyPress}
              placeholder="Type your message here..."
              className="flex-1 textarea textarea-bordered resize-none"
              rows={1}
            />
            <button
              className="btn btn-primary"
              onClick={handleSend}
              disabled={!input.trim()}
            >
              <Send size={20} />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}

export default ChatPage;