import React from 'react';
import { useNavigate } from 'react-router-dom';
import { ChevronLeft, ThumbsUp, MessageSquare, Share2, Plus } from 'lucide-react';

const mockPosts = [
  {
    id: 1,
    author: "Sarah Johnson",
    title: "My Recovery Journey",
    content: "Here's how I managed my training load during marathon preparation...",
    likes: 24,
    comments: 8,
    timestamp: "2 hours ago"
  },
  {
    id: 2,
    author: "Mike Chen",
    title: "Load Management Tips",
    content: "These are my top 5 strategies for maintaining optimal training load...",
    likes: 45,
    comments: 12,
    timestamp: "5 hours ago"
  },
  {
    id: 3,
    author: "Emma Wilson",
    title: "Weekly Progress Update",
    content: "Excited to share my latest achievements in load management...",
    likes: 18,
    comments: 5,
    timestamp: "1 day ago"
  }
];

function CommunityPage() {
  const navigate = useNavigate();

  return (
    <div className="min-h-screen bg-base-200">
      <div className="bg-base-100 shadow-md">
        <div className="max-w-7xl mx-auto px-4 py-4">
          <button
            onClick={() => navigate('/')}
            className="btn btn-ghost gap-2"
          >
            <ChevronLeft size={20} />
            <span>Back to Home</span>
          </button>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 py-8">
        <div className="flex justify-between items-center mb-8">
          <h1 className="text-2xl font-bold">Community Posts</h1>
          <button className="btn btn-primary gap-2">
            <Plus size={20} />
            New Post
          </button>
        </div>

        <div className="space-y-6">
          {mockPosts.map((post) => (
            <div key={post.id} className="card bg-base-100 shadow-xl">
              <div className="card-body">
                <div className="flex items-center gap-4 mb-4">
                  <div className="avatar placeholder">
                    <div className="bg-neutral text-neutral-content rounded-full w-12">
                      <span className="text-xl">{post.author[0]}</span>
                    </div>
                  </div>
                  <div>
                    <h3 className="font-bold">{post.author}</h3>
                    <p className="text-sm opacity-70">{post.timestamp}</p>
                  </div>
                </div>
                
                <h2 className="card-title">{post.title}</h2>
                <p>{post.content}</p>
                
                <div className="card-actions justify-between mt-6">
                  <div className="flex gap-6">
                    <button className="btn btn-ghost gap-2">
                      <ThumbsUp size={20} />
                      {post.likes}
                    </button>
                    <button className="btn btn-ghost gap-2">
                      <MessageSquare size={20} />
                      {post.comments}
                    </button>
                  </div>
                  <button className="btn btn-ghost">
                    <Share2 size={20} />
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

export default CommunityPage;