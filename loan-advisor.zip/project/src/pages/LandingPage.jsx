import React from 'react';
import { useNavigate } from 'react-router-dom';
import { MessageCircle, Users, UserCircle } from 'lucide-react';

function LandingPage() {
  const navigate = useNavigate();

  return (
    <div className="min-h-screen hero bg-gradient-to-b from-primary to-secondary">
      <div className="hero-content text-center">
        <div className="max-w-md">
          <h1 className="text-5xl font-bold text-base-100 mb-16">
            Load Advisor
          </h1>
          
          <div className="flex flex-col gap-4 w-full">
            <button
              className="btn btn-primary btn-lg w-full gap-3"
              onClick={() => navigate('/chat')}
            >
              <MessageCircle size={24} />
              <span className="text-lg">Chat</span>
            </button>

            <button
              className="btn btn-primary btn-lg w-full gap-3"
              onClick={() => navigate('/community')}
            >
              <Users size={24} />
              <span className="text-lg">Community</span>
            </button>

            <button
              className="btn btn-primary btn-lg w-full gap-3"
              onClick={() => navigate('/personal-details')}
            >
              <UserCircle size={24} />
              <span className="text-lg">Personal Details</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}

export default LandingPage;