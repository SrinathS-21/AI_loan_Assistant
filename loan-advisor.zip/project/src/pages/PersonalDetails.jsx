import React from 'react';
import { useNavigate } from 'react-router-dom';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend } from 'recharts';
import { ChevronLeft, Plus } from 'lucide-react';

const mockData = [
  { name: 'Jan', load: 4000 },
  { name: 'Feb', load: 3000 },
  { name: 'Mar', load: 2000 },
  { name: 'Apr', load: 2780 },
  { name: 'May', load: 1890 },
  { name: 'Jun', load: 2390 },
];

function PersonalDetails() {
  const navigate = useNavigate();

  return (
    <div className="min-h-screen bg-base-200">
      <div className="max-w-7xl mx-auto px-4 py-8">
        <button
          onClick={() => navigate('/')}
          className="btn btn-ghost gap-2 mb-8"
        >
          <ChevronLeft size={20} />
          <span>Back to Home</span>
        </button>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {/* Chart Section */}
          <div className="card bg-base-100 shadow-xl">
            <div className="card-body">
              <h2 className="card-title text-2xl">Load Overview</h2>
              <div className="overflow-x-auto">
                <LineChart width={500} height={300} data={mockData}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="name" />
                  <YAxis />
                  <Tooltip />
                  <Legend />
                  <Line type="monotone" dataKey="load" stroke="#3B82F6" />
                </LineChart>
              </div>
            </div>
          </div>

          {/* Records Section */}
          <div className="card bg-base-100 shadow-xl">
            <div className="card-body">
              <div className="flex justify-between items-center">
                <h2 className="card-title text-2xl">Records</h2>
                <button
                  className="btn btn-circle btn-primary"
                  onClick={() => alert('Add new record feature coming soon!')}
                >
                  <Plus size={24} />
                </button>
              </div>
              <div className="space-y-4 mt-6">
                {mockData.map((record, index) => (
                  <div
                    key={index}
                    className="flex justify-between items-center p-4 bg-base-200 rounded-lg hover:bg-base-300 transition-colors"
                  >
                    <span className="font-medium">{record.name}</span>
                    <div className="badge badge-primary badge-lg">{record.load} units</div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default PersonalDetails;